# frozen_string_literal: true

require_relative "vendor/optparse/lib/optparse"
